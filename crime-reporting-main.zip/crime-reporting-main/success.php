<?php
include 'php/includes/header.php';

?>
<div class="container" id="wrapper">
	<div id="header">
		<div class="mainLogo">
			<div class="logo"><img src="assets/images/lg.png" width="60px" height="50px" /> Crime <span> reporter</span></div>
		</div>
	</div>
	<div id="nav">
		<?php include 'php/includes/navigation.php' ?>
	</div>
	<div id="main">
		<div class="row">
			<div class="col-sm-12">
				<p>Thank you. Details received. Details are being reviewed for investigation</p>
			</div>
		</div>
	</div>
	<?php include 'php/includes/footer.php'; ?>