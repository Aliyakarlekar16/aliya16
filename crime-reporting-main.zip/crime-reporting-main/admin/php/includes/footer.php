<div id="footer">
	<p style="margin-top:5px;">Copyright &copy; Crime reporter <a href="#" title="email">By DeveloperName </a> </p>
	<div style="float:right; margin-top:-35px;margin-right:5px;">
		<a href="#"><img src="../assets/images/facebook_32.png" alt="" /></a>&nbsp;<a href="#"><img src="../assets/images/twitter_32.png" alt="" /></a>
	</div>
</div>
</div>
</body>

</html>